
public interface TacoBox {
    // int tacos=0;
    int tacosRemaining();

    void eat();

}
